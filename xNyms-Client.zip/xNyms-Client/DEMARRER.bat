@echo off
chcp 65001 >nul
cd /d "%~dp0"
title xNym's Client

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js n'est pas installe.
  echo  Installe la version LTS depuis https://nodejs.org puis relance ce fichier.
  echo.
  start https://nodejs.org
  pause
  exit /b 1
)

if not exist "node_modules\@xmcl\installer" (
  echo  Premiere utilisation : installation des composants, patiente une minute...
  call npm install
  if errorlevel 1 goto erreur
)

call npm start
exit /b 0

:erreur
echo.
echo  L'installation a echoue. Copie le message ci-dessus et envoie-le a Claude.
pause
exit /b 1
