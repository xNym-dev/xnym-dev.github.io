# xNym's Client

Launcher Minecraft limité à **1.8.9**, **1.19.4** et **1.21.8**, avec **Forge** ou **Fabric**.

## Lancer
Double-clique sur le raccourci **xNym's Client** du Bureau (ou sur `DEMARRER.bat`).
La première fois, il installe ses composants (Node.js LTS doit être installé).

## Les 3 onglets
- **Jouer** : connecte-toi avec Microsoft (en bas à gauche), choisis la version et le chargeur, puis JOUER. Java et Minecraft se téléchargent tout seuls.
- **Mods** : mods du profil choisi (ex. 1.8.9 Forge). Ajouter, activer/désactiver, mettre à la corbeille.
  Les mods marqués **intégré** sont installés et mis à jour par le launcher : le joueur ne peut pas les retirer.
- **Réglages** : RAM, Java automatique ou personnalisé, dossier du jeu.

## Nouveautés
- Thème noir et violet, fond de grotte (ou ton image : Réglages → Fond d'écran), tête du joueur.
- Mods préinstallés façon Lunar (HUD, zoom, freelook, toggle sprint, AutoGG…), waypoints (Xaero's Minimap)
  et inventaire à l'écran (InventoryHUD+). Les dépendances des mods s'installent toutes seules.
- Mods « proposés » : installés désactivés, le joueur les active dans l'onglet Mods (ex. Autofarm Clicker en 1.8.9 Forge).
  Pour en fournir un : mets le .jar dans `mods-locaux` et déclare-le dans `mods-integres.json` avec "local": true.
- Forge mis à jour : 1.19.4 → 45.4.5, 1.21.8 → 58.1.26.
- OptiFine : à ajouter soi-même (« Ajouter des mods »), profils Forge uniquement.

## Où sont les fichiers ?
`%APPDATA%\mon-launcher` :
- `partage\` : Minecraft, Forge, Fabric, librairies (communs à tout).
- `instances\1.19.4-fabric\` etc. : un dossier de jeu par profil (mods, mondes, options).
- `java\` : les Java téléchargés.
- `parametres.json` : les réglages. `compte.dat` : le compte Microsoft (chiffré par Windows).

---

## Étape 4 — Choisir les mods intégrés
Modifie `mods-integres.json`. Pour chaque profil, une liste de mods, au choix :

```json
"1.21.8-fabric": [
  { "modrinth": "fabric-api", "nom": "Fabric API" },
  { "modrinth": "sodium" },
  { "nom": "Mon mod", "fichier": "monmod-1.0.jar", "url": "https://exemple.com/monmod-1.0.jar", "sha1": "facultatif" }
]
```

- `"modrinth": "nom-du-projet"` : le nom qui apparaît dans l'adresse du mod sur modrinth.com
  (ex. `modrinth.com/mod/sodium` → `"sodium"`). Le launcher prend toujours la dernière version compatible.
- Sinon, un lien direct vers le fichier `.jar` (en `https://`).

Les mods sont vérifiés à chaque clic sur JOUER, ou avec « Mettre à jour les mods intégrés » dans l'onglet Mods.
Un mod retiré de la liste est retiré des joueurs au lancement suivant.

## Étape 5 — Mises à jour automatiques pour tous les joueurs
Pour changer la liste des mods **sans redistribuer le launcher** :
1. Mets ton `mods-integres.json` sur GitHub (dépôt public).
2. Ouvre le fichier sur GitHub, clique sur **Raw**, copie l'adresse.
3. Colle-la dans `lib\config.js` : `const URL_MODS_INTEGRES = 'https://raw.githubusercontent.com/...';`

Ensuite, chaque modification du fichier sur GitHub est appliquée chez les joueurs à leur prochain lancement.
Sans Internet, le launcher garde les mods déjà installés.

## Étape 6 — Activer la connexion Microsoft
Microsoft doit autoriser ton application avant qu'elle puisse ouvrir une session Minecraft.

1. Va sur **portal.azure.com** → « Inscriptions d'applications » → **Nouvelle inscription**.
   - Nom : `xNym's Client`
   - Types de comptes : **Comptes Microsoft personnels uniquement**
   - URI de redirection : plateforme **Client public/natif (mobile et bureau)**,
     adresse `https://login.microsoftonline.com/common/oauth2/nativeclient`
2. Dans **Authentification**, active **Autoriser les flux de clients publics** → Oui.
3. Copie l'**ID d'application (client)** et colle-le dans `lib\config.js` :
   `const AZURE_CLIENT_ID = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx';`
4. Relance le launcher et clique **Se connecter avec Microsoft** une fois (une erreur d'autorisation est normale à ce stade :
   Microsoft demande que l'application ait déjà été utilisée).
5. Remplis le formulaire d'approbation Minecraft : https://aka.ms/mce-reviewappid
   (type « New AppID for Approval », avec ton ID d'application et ton ID de locataire).
6. Après l'approbation de Microsoft (compter jusqu'à 24 h ensuite), la connexion fonctionne.

Le mode hors-ligne a été retiré : il faut un compte Microsoft qui possède Minecraft Java Edition pour jouer
(règle de Microsoft pour approuver l'application). Avant l'approbation, le bouton JOUER reste donc inutilisable.

---

## Tests automatiques
Double-clique sur **0-TEST.bat** : il installe les 6 profils et leurs mods intégrés (sans lancer le jeu),
puis écrit le résultat dans `outils\resultats.txt`.

## Notes techniques
- `@xmcl/installer` est figé en 6.1.2 et `@xmcl/unzip` en 2.1.2 (les versions plus récentes sont cassées).
- Pour 1.8.9 + Fabric, on garde le LWJGL d'origine (celui de Legacy Fabric n'a pas de fichiers Windows).
- Le dossier `server-resource-packs` est créé d'avance (bug de la 1.8.9 sur certains serveurs).
