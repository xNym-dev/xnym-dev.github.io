// main.js — le "cerveau" de xNym's Client (processus principal d'Electron).
// Il crée la fenêtre, gère les mods, les réglages, le compte Microsoft, puis installe et lance Minecraft.

const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');

const { VERSIONS, LOADERS, URL_MODS_INTEGRES, MODE_TEST } = require('./lib/config');
const { obtenirJava } = require('./lib/java');
const { preparerVersion } = require('./lib/installation');
const { lancerMinecraft, dossierInstance } = require('./lib/lancement');
const mods = require('./lib/mods');
const { creerParametres } = require('./lib/parametres');
const { creerCompte } = require('./lib/microsoft');

// Tous les fichiers du jeu vont dans %APPDATA%\mon-launcher (dossier gardé tel quel pour ne rien re-télécharger)
const DOSSIER_JEU = path.join(app.getPath('appData'), 'mon-launcher');
const DOSSIER_PARTAGE = path.join(DOSSIER_JEU, 'partage');     // versions, librairies, assets (partagés avec la copie de test)
const DOSSIER_JAVA = path.join(DOSSIER_JEU, 'java');
// La copie de test garde ses propres réglages, compte et instances (mods, mondes) pour ne rien abîmer
const DOSSIER_DONNEES = MODE_TEST ? path.join(app.getPath('appData'), 'mon-launcher-test') : DOSSIER_JEU;
const DOSSIER_INSTANCES = path.join(DOSSIER_DONNEES, 'instances'); // un dossier de jeu par version+loader

const parametres = creerParametres(DOSSIER_DONNEES);
const compte = creerCompte(DOSSIER_DONNEES);

let fenetre;

function creerFenetre() {
  fenetre = new BrowserWindow({
    width: 1040,
    height: 680,
    minWidth: 860,
    minHeight: 560,
    title: MODE_TEST ? "xNym's Client — TEST" : "xNym's Client",
    backgroundColor: '#14161a',
    icon: path.join(__dirname, 'icone', process.platform === 'win32' ? 'icone.ico' : 'icone.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  fenetre.setMenuBarVisibility(false);
  fenetre.loadFile(path.join(__dirname, 'src', 'index.html'));

  // Copie de test : l'interface se recharge toute seule dès qu'un fichier de src\ change
  if (MODE_TEST) {
    let minuteur = null;
    fs.watch(path.join(__dirname, 'src'), () => {
      clearTimeout(minuteur);
      minuteur = setTimeout(() => { if (!fenetre.isDestroyed()) fenetre.webContents.reloadIgnoringCache(); }, 300);
    });
  }
}

// Envoie un message de progression à l'interface
function statut(message) {
  console.log('[statut]', message);
  if (fenetre && !fenetre.isDestroyed()) fenetre.webContents.send('statut', message);
}

// Vérifie qu'un profil demandé par l'interface fait bien partie des 6 autorisés
function profilValide(version, loader) {
  if (!VERSIONS[version] || !LOADERS.includes(loader)) throw new Error('Version ou chargeur non autorisé.');
  return dossierInstance(DOSSIER_INSTANCES, version, loader);
}

// Enveloppe les réponses pour que l'interface reçoive toujours { ok, ... } au lieu d'une exception
function gerer(canal, fonction) {
  ipcMain.handle(canal, async (_evenement, ...args) => {
    try {
      return { ok: true, resultat: await fonction(...args) };
    } catch (erreur) {
      console.error(canal, erreur);
      return { ok: false, message: erreur && erreur.message ? erreur.message : String(erreur) };
    }
  });
}

// ── Choix du Java : automatique, ou celui choisi par le joueur dans les réglages ──
async function javaPour(version) {
  const majeur = VERSIONS[version].java;
  const p = parametres.lire();
  const perso = p.javaPerso[String(majeur)];
  if (!p.javaAuto && perso) {
    if (fs.existsSync(perso)) return perso;
    statut(`Java ${majeur} personnalisé introuvable, utilisation du Java automatique`);
  }
  return obtenirJava(majeur, DOSSIER_JAVA, statut);
}

// ── Lancement ────────────────────────────────────────────────────────────────
let enCours = false;

gerer('lancer-jeu', async ({ version, loader, pseudo }) => {
  if (enCours) throw new Error('Un lancement est déjà en cours.');
  const instance = profilValide(version, loader);

  enCours = true;
  try {
    let infosCompte;
    if (MODE_TEST && !compte.etat().connecte) {
      // Copie de test uniquement : pseudo hors-ligne pour essayer l'interface
      pseudo = String(pseudo || '').trim();
      if (!/^[A-Za-z0-9_]{3,16}$/.test(pseudo)) throw new Error('Pseudo invalide : 3 à 16 caractères, lettres, chiffres ou _');
      infosCompte = { nom: pseudo, horsLigne: true };
      parametres.ecrire({ pseudo });
    } else {
      // Compte Microsoft obligatoire : Minecraft ne se lance qu'avec un compte qui possède le jeu
      if (!compte.etat().connecte) {
        throw new Error('Connecte-toi avec ton compte Microsoft (en bas à gauche) pour jouer.');
      }
      statut('Vérification du compte Microsoft…');
      const s = await compte.session();
      infosCompte = { nom: s.nom, uuid: s.uuid, jeton: s.jeton };
    }
    parametres.ecrire({ version, loader });

    for (const d of [DOSSIER_PARTAGE, DOSSIER_INSTANCES, DOSSIER_JAVA]) fs.mkdirSync(d, { recursive: true });

    // Profil OptiFine : le fichier OptiFine doit avoir été ajouté par le joueur
    if (loader === 'optifine' && !optifinePresent(instance)) {
      throw new Error("OptiFine n'est pas encore installé pour ce profil : clique sur « Télécharger OptiFine », puis « Ajouter le fichier OptiFine ».");
    }

    const javaPath = await javaPour(version);
    const idVersion = await preparerVersion({
      mcVersion: version, loader, dossierPartage: DOSSIER_PARTAGE, javaPath, statut
    });

    // Mods intégrés : installés / mis à jour avant chaque partie
    await mods.synchroniserModsIntegres(version, loader, instance, statut);

    statut('Lancement de Minecraft…');
    const processus = await lancerMinecraft({
      idVersion, mcVersion: version, loader,
      dossierPartage: DOSSIER_PARTAGE, dossierInstances: DOSSIER_INSTANCES,
      javaPath, compte: infosCompte, ramMo: parametres.lire().ramMo
    });

    // Les logs du jeu sont gardés dans un fichier, très utile pour comprendre un crash
    const fichierLog = path.join(instance, 'launcher-log.txt');
    const log = fs.createWriteStream(fichierLog);
    processus.stdout?.pipe(log);
    processus.stderr?.pipe(log);
    processus.on('exit', (code) => {
      if (code === 0) statut('Minecraft fermé. Prêt.');
      else statut(`Minecraft s'est arrêté avec une erreur (code ${code}). Log : ${fichierLog}`);
    });

    return `Minecraft ${version} (${loader}) démarre en tant que ${infosCompte.nom} !`;
  } finally {
    enCours = false;
  }
});

// ── OptiFine ────────────────────────────────────────────────────────────────
function optifinePresent(instance) {
  const dossier = path.join(instance, 'mods');
  return fs.existsSync(dossier) && fs.readdirSync(dossier).some((f) => /optifine/i.test(f) && /\.jar$/i.test(f));
}

gerer('optifine:etat', ({ version, loader }) => optifinePresent(profilValide(version, loader)));

// Ouvre la page officielle de téléchargement (OptiFine ne peut être téléchargé que depuis optifine.net)
gerer('optifine:telecharger', () => shell.openExternal('https://optifine.net/downloads'));

gerer('optifine:ajouter', async ({ version }) => {
  const instance = profilValide(version, 'optifine');
  const choix = await dialog.showOpenDialog(fenetre, {
    title: `Choisir le fichier OptiFine pour ${version}`,
    defaultPath: app.getPath('downloads'),
    filters: [{ name: 'OptiFine', extensions: ['jar'] }],
    properties: ['openFile']
  });
  if (choix.canceled) return optifinePresent(instance);
  const nom = path.basename(choix.filePaths[0]);
  if (!/optifine/i.test(nom)) throw new Error('Ce fichier ne ressemble pas à OptiFine (son nom doit contenir « OptiFine »).');
  if (!nom.includes(version)) statut(`Attention : ce fichier OptiFine ne semble pas fait pour la ${version}.`);
  const dossier = path.join(instance, 'mods');
  fs.mkdirSync(dossier, { recursive: true });
  for (const f of fs.readdirSync(dossier)) if (/optifine/i.test(f)) fs.rmSync(path.join(dossier, f), { force: true }); // une seule version d'OptiFine
  fs.copyFileSync(choix.filePaths[0], path.join(dossier, nom));
  statut(`OptiFine ajouté : ${nom}`);
  return true;
});

// ── Étape 4 : mods ───────────────────────────────────────────────────────────
gerer('mods:lister', ({ version, loader }) => mods.listerMods(profilValide(version, loader)));

gerer('mods:basculer', ({ version, loader, fichier }) => {
  mods.basculerMod(profilValide(version, loader), fichier);
  return mods.listerMods(profilValide(version, loader));
});

gerer('mods:ajouter', async ({ version, loader }) => {
  const instance = profilValide(version, loader);
  const choix = await dialog.showOpenDialog(fenetre, {
    title: `Ajouter des mods (${version} ${loader})`,
    filters: [{ name: 'Mods Minecraft', extensions: ['jar'] }],
    properties: ['openFile', 'multiSelections']
  });
  if (!choix.canceled) mods.ajouterMods(instance, choix.filePaths);
  return mods.listerMods(instance);
});

gerer('mods:supprimer', async ({ version, loader, fichier }) => {
  const instance = profilValide(version, loader);
  await shell.trashItem(mods.cheminModJoueur(instance, fichier)); // va dans la Corbeille, récupérable
  return mods.listerMods(instance);
});

gerer('mods:ouvrir-dossier', async ({ version, loader }) => {
  const dossier = path.join(profilValide(version, loader), 'mods');
  fs.mkdirSync(dossier, { recursive: true });
  await shell.openPath(dossier);
});

gerer('mods:mettre-a-jour', async ({ version, loader }) => {
  const instance = profilValide(version, loader);
  const r = await mods.synchroniserModsIntegres(version, loader, instance, statut);
  statut(r.incomplet
    ? 'Mise à jour des mods intégrés partielle (voir messages ci-dessus).'
    : `Mods intégrés à jour (${r.total} mod${r.total > 1 ? 's' : ''}, ${r.installes} téléchargé${r.installes > 1 ? 's' : ''}).`);
  return mods.listerMods(instance);
});

// ── Étape 5 : réglages ───────────────────────────────────────────────────────
gerer('reglages:lire', () => ({ ...parametres.lire(), urlModsIntegres: URL_MODS_INTEGRES || null, modeTest: MODE_TEST }));
gerer('reglages:ecrire', (maj) => parametres.ecrire(maj));

gerer('reglages:choisir-java', async (majeur) => {
  if (!['8', '17', '21'].includes(String(majeur))) throw new Error('Version de Java inconnue.');
  const choix = await dialog.showOpenDialog(fenetre, {
    title: `Choisir javaw.exe pour Java ${majeur}`,
    filters: [{ name: 'Java', extensions: ['exe'] }],
    properties: ['openFile']
  });
  if (choix.canceled) return parametres.lire();
  const p = parametres.lire();
  return parametres.ecrire({ javaPerso: { ...p.javaPerso, [String(majeur)]: choix.filePaths[0] } });
});

// Fond d'écran : l'image choisie est copiée dans le dossier du launcher, puis envoyée à l'interface
const TYPES_IMAGE = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' };

gerer('reglages:choisir-fond', async () => {
  const choix = await dialog.showOpenDialog(fenetre, {
    title: "Choisir une image de fond",
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif'] }],
    properties: ['openFile']
  });
  if (choix.canceled) return parametres.lire();
  const ext = path.extname(choix.filePaths[0]).toLowerCase();
  if (!TYPES_IMAGE[ext]) throw new Error('Format d\'image non pris en charge.');
  const copie = path.join(DOSSIER_DONNEES, 'fond' + ext);
  fs.mkdirSync(DOSSIER_DONNEES, { recursive: true });
  fs.copyFileSync(choix.filePaths[0], copie);
  return parametres.ecrire({ fond: copie });
});

gerer('reglages:fond-defaut', () => parametres.ecrire({ fond: '' }));

gerer('reglages:image-fond', () => {
  const fond = parametres.lire().fond;
  if (!fond || !fs.existsSync(fond)) return null;
  const type = TYPES_IMAGE[path.extname(fond).toLowerCase()];
  if (!type) return null;
  return `data:${type};base64,${fs.readFileSync(fond).toString('base64')}`;
});

gerer('reglages:ouvrir-dossier-jeu', async () => {
  fs.mkdirSync(DOSSIER_JEU, { recursive: true });
  await shell.openPath(DOSSIER_JEU);
});

// ── Étape 6 : compte Microsoft ───────────────────────────────────────────────
gerer('compte:etat', () => compte.etat());
gerer('compte:connecter', () => compte.connecter(fenetre));
gerer('compte:deconnecter', () => compte.deconnecter());

app.whenReady().then(() => {
  creerFenetre();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) creerFenetre();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
