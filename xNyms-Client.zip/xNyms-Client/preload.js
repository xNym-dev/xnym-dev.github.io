// preload.js — le "pont" sécurisé entre l'interface (HTML) et main.js.
// On n'expose que ce dont l'interface a besoin, rien de plus.

const { contextBridge, ipcRenderer } = require('electron');

const appeler = (canal) => (...args) => ipcRenderer.invoke(canal, ...args);

contextBridge.exposeInMainWorld('launcher', {
  lancerJeu: appeler('lancer-jeu'),
  surStatut: (callback) => ipcRenderer.on('statut', (_evenement, message) => callback(message)),

  optifine: {
    etat: appeler('optifine:etat'),
    telecharger: appeler('optifine:telecharger'),
    ajouter: appeler('optifine:ajouter')
  },

  mods: {
    lister: appeler('mods:lister'),
    basculer: appeler('mods:basculer'),
    ajouter: appeler('mods:ajouter'),
    supprimer: appeler('mods:supprimer'),
    ouvrirDossier: appeler('mods:ouvrir-dossier'),
    mettreAJour: appeler('mods:mettre-a-jour')
  },

  reglages: {
    lire: appeler('reglages:lire'),
    ecrire: appeler('reglages:ecrire'),
    choisirJava: appeler('reglages:choisir-java'),
    ouvrirDossierJeu: appeler('reglages:ouvrir-dossier-jeu'),
    choisirFond: appeler('reglages:choisir-fond'),
    fondDefaut: appeler('reglages:fond-defaut'),
    imageFond: appeler('reglages:image-fond')
  },

  compte: {
    etat: appeler('compte:etat'),
    connecter: appeler('compte:connecter'),
    deconnecter: appeler('compte:deconnecter')
  }
});
