// renderer.js — l'interface : onglets, choix du profil, mods, réglages et compte.

const L = window.launcher;
const $ = (id) => document.getElementById(id);

const etat = { version: '1.8.9', loader: 'forge', reglages: null, compte: null };
const NOMS_LOADER = { forge: 'Forge', optifine: 'OptiFine', fabric: 'Fabric' };
const VERSIONS = ['1.8.9', '1.19.4', '1.21.4', '1.21.8'];

function afficherStatut(message) { $('statut').textContent = message; }
L.surStatut(afficherStatut);

// Toutes les réponses de main.js ont la forme { ok, resultat } ou { ok: false, message }
async function demander(promesse) {
  const r = await promesse;
  if (!r.ok) { afficherStatut('Erreur : ' + r.message); throw new Error(r.message); }
  return r.resultat;
}

// ── Onglets ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.onglet').forEach((bouton) => {
  bouton.addEventListener('click', () => {
    document.querySelectorAll('.onglet').forEach((b) => b.classList.toggle('actif', b === bouton));
    document.querySelectorAll('.vue').forEach((v) => v.classList.toggle('active', v.id === 'vue-' + bouton.dataset.vue));
    if (bouton.dataset.vue === 'mods') chargerMods();
  });
});

// ── Choix version / chargeur ────────────────────────────────────────────────
function marquerSelection() {
  $('liste-versions').value = etat.version;
  document.querySelectorAll('#loaders .carte').forEach((c) => c.classList.toggle('selection', c.dataset.loader === etat.loader));
  const profil = `${etat.version} ${NOMS_LOADER[etat.loader]}`;
  $('resume').textContent = profil;
  $('titre-mods').textContent = `Mods — ${profil}`;
  majOptifine();
}

// Profil OptiFine : explique comment l'installer tant que le fichier n'est pas là
async function majOptifine() {
  const bloc = $('bloc-optifine');
  if (etat.loader !== 'optifine') { bloc.classList.add('cache'); return; }
  bloc.classList.remove('cache');
  let present = false;
  try { present = await demander(L.optifine.etat({ version: etat.version, loader: 'optifine' })); } catch (_) { /* affiché */ }
  $('optifine-info').textContent = present
    ? `OptiFine est installé pour la ${etat.version} (avec Forge). Tu peux jouer.`
    : `OptiFine pour la ${etat.version} : télécharge la version « ${etat.version} » sur optifine.net (bouton « Download », pas « Mirror » si une pub s'affiche), puis clique sur « Ajouter le fichier OptiFine ».`;
}
$('optifine-telecharger').addEventListener('click', () => demander(L.optifine.telecharger()).catch(() => {}));
$('optifine-ajouter').addEventListener('click', async () => {
  try { await demander(L.optifine.ajouter({ version: etat.version })); majOptifine(); } catch (_) { /* affiché */ }
});
$('liste-versions').addEventListener('change', () => { etat.version = $('liste-versions').value; marquerSelection(); });
document.querySelectorAll('#loaders .carte').forEach((c) => c.addEventListener('click', () => { etat.loader = c.dataset.loader; marquerSelection(); }));

// ── Jouer ───────────────────────────────────────────────────────────────────
$('jouer').addEventListener('click', async () => {
  const bouton = $('jouer');
  bouton.disabled = true;
  afficherStatut('Préparation… (le premier lancement d\'une version peut prendre plusieurs minutes)');
  try {
    const message = await demander(L.lancerJeu({ version: etat.version, loader: etat.loader, pseudo: $('pseudo').value.trim() }));
    afficherStatut(message);
  } catch (_) { /* déjà affiché */ } finally {
    bouton.disabled = !(etat.compte && etat.compte.connecte) && !(etat.reglages && etat.reglages.modeTest);
  }
});

// ── Mods ────────────────────────────────────────────────────────────────────
const profil = () => ({ version: etat.version, loader: etat.loader });

function afficherMods(liste) {
  const ul = $('liste-mods');
  ul.replaceChildren();
  $('mods-vide').style.display = liste.length ? 'none' : 'block';

  for (const mod of liste) {
    const li = document.createElement('li');
    li.className = 'mod' + (mod.actif ? '' : ' inactif');

    const nom = document.createElement('div');
    nom.className = 'mod-nom';
    nom.textContent = mod.nom;
    const infos = document.createElement('small');
    infos.textContent = `${mod.tailleKo} Ko`;
    nom.appendChild(infos);
    if (mod.integre || mod.propose) {
      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.textContent = mod.integre ? 'intégré' : 'proposé';
      nom.appendChild(badge);
    }

    const actions = document.createElement('div');
    actions.className = 'mod-actions';
    if (!mod.integre) {
      const interrupteur = document.createElement('label');
      interrupteur.className = 'interrupteur';
      interrupteur.title = mod.actif ? 'Désactiver' : 'Activer';
      const caseActif = document.createElement('input');
      caseActif.type = 'checkbox';
      caseActif.checked = mod.actif;
      caseActif.addEventListener('change', async () => {
        try { afficherMods(await demander(L.mods.basculer({ ...profil(), fichier: mod.fichier }))); } catch (_) { chargerMods(); }
      });
      interrupteur.append(caseActif, document.createElement('span'));

      const supprimer = document.createElement('button');
      supprimer.className = 'icone';
      supprimer.title = 'Mettre à la corbeille';
      supprimer.textContent = 'Supprimer';
      if (mod.propose) supprimer.style.display = 'none'; // un mod proposé se gère avec l'interrupteur
      supprimer.addEventListener('click', async () => {
        if (!confirm(`Mettre « ${mod.nom} » à la corbeille ?`)) return;
        try { afficherMods(await demander(L.mods.supprimer({ ...profil(), fichier: mod.fichier }))); } catch (_) { /* affiché */ }
      });
      actions.append(interrupteur, supprimer);
    } else {
      const verrou = document.createElement('small');
      verrou.className = 'aide';
      verrou.textContent = 'géré par le launcher';
      actions.append(verrou);
    }

    li.append(nom, actions);
    ul.appendChild(li);
  }
}

async function chargerMods() {
  try { afficherMods(await demander(L.mods.lister(profil()))); } catch (_) { /* affiché */ }
}

$('mods-ajouter').addEventListener('click', async () => {
  try { afficherMods(await demander(L.mods.ajouter(profil()))); } catch (_) { /* affiché */ }
});
$('mods-dossier').addEventListener('click', () => demander(L.mods.ouvrirDossier(profil())).catch(() => {}));
$('mods-maj').addEventListener('click', async () => {
  const b = $('mods-maj');
  b.disabled = true;
  try { afficherMods(await demander(L.mods.mettreAJour(profil()))); } catch (_) { /* affiché */ } finally { b.disabled = false; }
});

// ── Réglages ────────────────────────────────────────────────────────────────
function afficherReglages(r) {
  etat.reglages = r;
  const ram = $('ram');
  ram.max = r.ramMaxMo;
  ram.value = r.ramMo;
  $('ram-valeur').textContent = (r.ramMo / 1024).toFixed(1).replace('.0', '') + ' Go';
  $('ram-aide').textContent = `Conseil : 4 Go suffisent pour la plupart des parties, 6 à 8 Go pour beaucoup de mods. Maximum sur ce PC : ${Math.floor(r.ramMaxMo / 1024)} Go.`;

  $('java-auto').checked = r.javaAuto;
  $('java-perso').classList.toggle('cache', r.javaAuto);
  document.querySelectorAll('.ligne-java').forEach((ligne) => {
    ligne.querySelector('code').textContent = r.javaPerso[ligne.dataset.java] || 'non choisi (automatique)';
  });

  $('source-mods').textContent = r.urlModsIntegres
    ? `Mis à jour automatiquement depuis : ${r.urlModsIntegres}`
    : 'Liste locale : fichier mods-integres.json du launcher (mise à jour en ligne non configurée).';
}

$('ram').addEventListener('input', () => {
  $('ram-valeur').textContent = (Number($('ram').value) / 1024).toFixed(1).replace('.0', '') + ' Go';
});
$('ram').addEventListener('change', async () => {
  try { afficherReglages(await demander(L.reglages.ecrire({ ramMo: Number($('ram').value) }))); } catch (_) { /* affiché */ }
});
$('java-auto').addEventListener('change', async () => {
  try { afficherReglages(await demander(L.reglages.ecrire({ javaAuto: $('java-auto').checked }))); } catch (_) { /* affiché */ }
});
document.querySelectorAll('.ligne-java button').forEach((b) => {
  b.addEventListener('click', async () => {
    try { afficherReglages(await demander(L.reglages.choisirJava(b.parentElement.dataset.java))); } catch (_) { /* affiché */ }
  });
});
$('ouvrir-dossier-jeu').addEventListener('click', () => demander(L.reglages.ouvrirDossierJeu()).catch(() => {}));

// ── Tête du joueur ──────────────────────────────────────────────────────────
// Rendu du skin par mc-heads.net (par UUID pour un compte Microsoft, par pseudo sinon),
// avec crafatar.com en secours, et la tête de Steve si rien n'est disponible.
function adressesTete(taille) {
  const c = etat.compte || {};
  const id = c.connecte ? c.uuid : ($('pseudo').value.trim() || 'MHF_Steve');
  const liste = [`https://mc-heads.net/avatar/${encodeURIComponent(id)}/${taille}`];
  if (c.connecte && c.uuid) liste.push(`https://crafatar.com/avatars/${c.uuid}?size=${taille}&overlay`);
  liste.push(`https://mc-heads.net/avatar/MHF_Steve/${taille}`);
  return liste;
}
function chargerTete(img, taille) {
  const adresses = adressesTete(taille);
  let i = 0;
  img.onerror = () => { i++; if (i < adresses.length) img.src = adresses[i]; else img.removeAttribute('src'); };
  img.src = adresses[0];
}
function afficherJoueur() {
  const c = etat.compte || {};
  const nom = c.connecte ? c.nom : ($('pseudo').value.trim() || 'Joueur');
  $('joueur-nom').textContent = nom;
  chargerTete($('grande-tete'), 128);
  chargerTete($('compte-tete'), 64);
}
let minuteurPseudo = null;
$('pseudo').addEventListener('input', () => {
  clearTimeout(minuteurPseudo);
  minuteurPseudo = setTimeout(afficherJoueur, 500);
});

// ── Fond d'écran ────────────────────────────────────────────────────────────
async function appliquerFond() {
  try {
    const image = await demander(L.reglages.imageFond());
    $('fond').style.backgroundImage = image ? `url("${image}")` : '';
    $('fond').style.imageRendering = image ? 'auto' : '';
  } catch (_) { /* affiché */ }
}
$('fond-choisir').addEventListener('click', async () => {
  try { afficherReglages(await demander(L.reglages.choisirFond())); await appliquerFond(); } catch (_) { /* affiché */ }
});
$('fond-defaut').addEventListener('click', async () => {
  try { afficherReglages(await demander(L.reglages.fondDefaut())); await appliquerFond(); } catch (_) { /* affiché */ }
});

// ── Compte Microsoft ────────────────────────────────────────────────────────
function afficherCompte(c) {
  etat.compte = c;
  afficherJoueur();
  $('compte-nom').textContent = c.connecte ? c.nom : 'Non connecté';
  $('compte-detail').textContent = c.connecte ? 'Compte Microsoft' : 'Connexion obligatoire pour jouer';
  $('compte-bouton').textContent = c.connecte ? 'Se déconnecter' : 'Se connecter avec Microsoft';
  const test = Boolean(etat.reglages && etat.reglages.modeTest);
  $('bloc-pseudo').classList.toggle('cache', c.connecte || !test);
  $('jouer').disabled = !c.connecte && !test;
  $('info-compte').textContent = test && !c.connecte
    ? 'Copie de test : tu peux jouer hors-ligne avec un pseudo.'
    : c.connecte
    ? `Tu joueras en tant que ${c.nom}.`
    : 'Connecte-toi avec ton compte Microsoft (en bas à gauche) pour pouvoir jouer. Un compte qui possède Minecraft Java Edition est nécessaire.';
}

$('compte-bouton').addEventListener('click', async () => {
  const b = $('compte-bouton');
  b.disabled = true;
  try {
    if (etat.compte && etat.compte.connecte) {
      afficherCompte(await demander(L.compte.deconnecter()));
      afficherStatut('Déconnecté.');
    } else {
      afficherStatut('Connexion Microsoft en cours… (une fenêtre s\'ouvre)');
      const c = await demander(L.compte.connecter());
      afficherCompte(c);
      afficherStatut(`Connecté en tant que ${c.nom}.`);
    }
  } catch (_) { /* affiché */ } finally {
    b.disabled = false;
  }
});

// ── Démarrage ───────────────────────────────────────────────────────────────
(async () => {
  try {
    const r = await demander(L.reglages.lire());
    afficherReglages(r);
    $('etiquette-test').classList.toggle('cache', !r.modeTest);
    $('pseudo').value = r.pseudo || '';
    if (VERSIONS.includes(r.version)) etat.version = r.version;
    if (NOMS_LOADER[r.loader]) etat.loader = r.loader;
  } catch (_) { /* affiché */ }
  marquerSelection();
  try { afficherCompte(await demander(L.compte.etat())); } catch (_) { /* affiché */ }
  appliquerFond();
})();
